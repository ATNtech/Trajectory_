<?php

namespace Chetkov\YaMapsParser\Exception;

use Exception;

/**
 * Class EmptyResultException
 * @package Chetkov\YaMapsParser\Exception
 */
class EmptyResultException extends Exception
{

}
